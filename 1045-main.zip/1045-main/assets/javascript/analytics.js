!function(o,b,n,x,i,u,s){o.GoogleAnalyticsObject=n;o[n]||(o[n]=function(){
(o[n].q=o[n].q||[]).push(arguments)});o[n].x=+new Date;u=b.createElement(x);
s=b.getElementsByTagName(x)[0];u.src=i;s.parentNode.insertBefore(u,s)}
(window,document,'ga','script','https://www.google-analytics.com/analytics.js');

ga('create', 'UA-122247573-1', 'fullbright.xxx');
ga('send', 'pageview');
